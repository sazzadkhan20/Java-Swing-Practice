import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Calculator extends JFrame implements ActionListener{

	Font font = new Font("cambria", Font.PLAIN, 25);
	JTextField screen;
	JButton btn7,btn8;
	JButton btnPlus,btnEq;
	
	double op1,op2,result;
	String operator = "";
	public Calculator(){
		//Creating the Main Window
		super("My Calculator");
		this.setSize(400,600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocation(300,50);
		this.setLayout(null);
		
		//Creating a Panel Container
		JPanel panel = new JPanel();
		panel.setBounds(0,0,400,600);
		panel.setBackground( new Color(120,253,132));
		panel.setLayout(null);
		
		//Crating a Label
		JLabel label = new JLabel("Model : OOP1 Sec-C");
		label.setBounds(10,10,360,30);
		label.setFont(font);
		
		//Creating the Screen
		screen = new JTextField();
		screen.setBounds(10,50,360,50);
		screen.setFont(font);
		
		//+++++++Creating the Buttons+++++++
		
		btn7 = new JButton("7");
		btn7.setBounds(10,110,50,50);
		btn7.setFont(font);
		btn7.setBackground(new Color(53,253,230));
		btn7.addActionListener(this);
		
		btn8 = new JButton("8");
		btn8.setBounds(70,110,50,50);
		btn8.setFont(font);
		btn8.setBackground(new Color(53,253,230));
		btn8.addActionListener(this);
		
		btnPlus = new JButton("+");
		btnPlus.setBounds(130,110,50,50);
		btnPlus.setFont(font);
		btnPlus.setBackground(new Color(53,253,230));
		btnPlus.addActionListener(this);
		
		
		btnEq = new JButton("=");
		btnEq.setBounds(190,110,50,50);
		btnEq.setFont(font);
		btnEq.setBackground(new Color(53,253,230));
		btnEq.addActionListener(this);
		
		//Add Components to Window
		panel.add(label);
		panel.add(screen);
		panel.add(btn7);
		panel.add(btn8);
		panel.add(btnPlus);
		panel.add(btnEq);
		this.add(panel);
		//Display the window after all initialization
		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e){
		String command = e.getActionCommand();
		System.out.println("Clicked "+e.getActionCommand());
		
		if(btn7 == e.getSource() || 
		   btn8 == e.getSource() ){
			screen.setText(screen.getText()+command);   
		}
		else if(btnPlus == e.getSource() ){
				op1 = Double.parseDouble(screen.getText()) ;
				operator = command;
				screen.setText("");
		}
		else if(btnEq == e.getSource() ){
			op2 = Double.parseDouble(screen.getText());
			
			if(operator.equals("+")){result = op1+op2;}
			else if(operator.equals("-")){result = op1-op2;}
			else if(operator.equals("*")){result = op1*op2;}
			else if(operator.equals("/")){result = op1/op2;}
			
			op1 = result;
			screen.setText(""+result);
		}
		
	}
}