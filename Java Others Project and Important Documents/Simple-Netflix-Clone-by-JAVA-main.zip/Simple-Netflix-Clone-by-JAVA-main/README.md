# Simple-Netflix-Clone-by-JAVA
It's a simple clone of NETFLIX for desktop. The project is built by using java only. No external packages or libraries are added to this project.
Download the zip file.
Open the Main.java file.
Write "javac Main.java" for compiling the Main class.
Write "java Main" for running the application.
Initally you will find the home interface empty. You need to add contents from the admin panel.
For adding content open "Admin.java" file.
Write "javac Admin.java" for compiling.
Write "java Admin" for openning the admin panel. You will be asked for security password. Initially the password is "888".
Add content from the Admin panel than reload the main interface. You will find the contents in main application.
*****N.B: As there are no external package or libraries added in the project, so the video playing option will not work.******
