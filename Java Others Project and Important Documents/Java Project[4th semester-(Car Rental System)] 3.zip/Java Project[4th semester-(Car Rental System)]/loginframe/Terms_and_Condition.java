

package loginframe;
import javax.swing.*;


public class Terms_and_Condition extends JFrame {
    
    protected JPanel panel;
    protected JLabel label1,label2;
    
    public Terms_and_Condition()
    {
        label1 = new JLabel();
        label2 = new JLabel();
        
    }
    
    
}
