import Admin.*;
import Customer.*;
import loginframe.*;
import Classes.*;
import Admin.Garage;

public class Start

{
    public static void main(String []args)
    {
      
     new HomePage(); 
	// new MobileBanking();
	
	
	

   }
    
}