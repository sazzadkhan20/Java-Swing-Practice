
package Classes;


public class BMW extends Car{
    
    
    public BMW(String brandName,String model,String carID,String color,double price,String status)
    
    {
        super(brandName,model,carID,color,price,status);
        
        
    }
	
	
	
    
    
}
