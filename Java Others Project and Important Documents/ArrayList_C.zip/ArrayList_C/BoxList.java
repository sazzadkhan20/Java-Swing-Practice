public class BoxList{ // list of objects
	private Box boxes[]; //array of object
	
	public BoxList(){
		boxes = new Box[5];
	}
	public BoxList(int size){
		boxes = new Box[size];
	}
	//show all boxes inside boxList
	void showAllBoxes(){
		for(int i=0;i<boxes.length;i++){
			//looking for non-empty cell
			if(boxes[i] != null){
				boxes[i].showBox();
			}
		}
	}
	
	
	//insert box into array
	void insertBox(Box b){
		boolean flag = false; //consider the work is incomplete
		for(int i=0;i<boxes.length;i++){
			//looking for empty cell
			if(boxes[i] == null){
				boxes[i] = b;
				flag = true; //the work is done
				break; //stopping after saving the box
			}
		}
		//How Will you know that the Box is 
		//Successfully Placed into the array??
		if(flag){
			System.out.println("Box Inserted");
		}
		else{
			System.out.println("Book List is Full!! Cannot Save this Box");
		}
	}
	
	//finding the area of all box
	double getTotalAreaOfBoxes(){
		double totalArea = 0;
		for(int i=0;i<boxes.length;i++){
			//looking for non-empty cell
			if(boxes[i] != null){
				//calculate area of a single object and
				//store the summation into totalArea variable
				totalArea = totalArea + boxes[i].getArea();
			}
		}
		return totalArea;
	}
	
}