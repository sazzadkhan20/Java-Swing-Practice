public class Box{
	//instance variabls
	private double length;
	private double width;
	private double height;
	
	public static int BoxCounter;

	//Empty Constructor
	public Box(){BoxCounter++;} 
	
	//Parameterized Constructor
	public Box(double l, double w, double h){
		length = l;
		width = w;
		height = h;
		BoxCounter++;
	}
	
	
	//Setter Methos
	public void setLength(double v){length = v;}
	public void setWidth(double v){width = v;}
	public void setHeight(double v){height = v;}
	
	//Getter Methods
	public double getLength(){return length;}
	public double getWidth(){return width;}
	public double getHeight(){return height;}
	
	//instance method
	public void showBox(){
		System.out.println("-------------------");
		System.out.println("Length : "+length);
		System.out.println("Width : "+width);
		System.out.println("Height : "+height);
		System.out.println("-------------------");
	}
	
	public double getArea(){
		return length*width;
	}
}

