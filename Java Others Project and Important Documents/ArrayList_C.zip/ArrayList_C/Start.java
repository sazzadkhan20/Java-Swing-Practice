import java.util.Scanner;
public class Start{
	public static void main(String []args){
		Scanner scNum = new Scanner(System.in);
		Scanner scStr = new Scanner(System.in);
		
		BoxList boxList = new BoxList(5);
		
		boxList.insertBox(new Box(1,2,3));
		boxList.insertBox(new Box(2,2,3));
		boxList.insertBox(new Box(3,2,3));
		boxList.insertBox(new Box(4,2,3));

		boxList.showAllBoxes();
		
		//find the sum of area of all Boxes??
		System.out.println("Total Area: "+boxList.getTotalAreaOfBoxes());
	}
}