# Driver Chai
Features:
  1. Drivers and customer can signup and login to their account.
  2. Driver can fill up the necessary things in the signup page along with years of experience and prefered car type.
  3. Customer can search driver with prefered criteria.
  4. If Customer find his/her perefered driver he/she can hire and will see a success message.
  5. Admin can see all the users information by login into admin portal.
