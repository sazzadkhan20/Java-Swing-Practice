public class FixedDepositAccount extends Account{
	
	private int tenureYear=1;
	
	public FixedDepositAccount(){};
	
	public FixedDepositAccount(int accountNumber, String accountHolderName, 
							   double balance,int tenureYear){
		super(accountNumber,accountHolderName,balance);
		System.out.println("FD ACCOUNT");
		this.tenureYear = tenureYear;
	}
	
	public void setTenureYear(int tenureYear){
			this.tenureYear = tenureYear;
		}
	public int getTenureYear(){return this.tenureYear;}
	
	public void showDetails(){
		super.showDetails();
		System.out.println("Tenure Year : "+this.tenureYear);
	}
}