public class OverDraftAccount extends SavingsAccount{
	private double limit;
	public OverDraftAccount(int accountNumber, 
							  String accountHolderName, 
							  double balance, 
							  double interestRate,
							  double limit){
			super(accountNumber,accountHolderName,balance,interestRate);
			this.limit = limit;  
		}
		
		public void withdraw(double amount){
		if(super.getBalance()+limit>=amount){
			super.setBalance(super.getBalance() - amount);
			System.out.println("Successfully WithDrawn : "+amount);
		}
		else{
			System.out.println("Not Enough Balance");
		}
	}
		
		public void showDetails(){
			super.showDetails();
			System.out.println("Over Draft Limit: "+this.limit);
		}
}