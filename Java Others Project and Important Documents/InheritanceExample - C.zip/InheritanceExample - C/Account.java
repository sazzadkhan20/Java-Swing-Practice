import java.lang.*;

public class Account
{
	protected int accountNumber;
	protected String accountHolderName;
	private double balance;
	
	public Account()
	{		
		System.out.println("Empty Account");
		this.accountNumber= -1;
		this.accountHolderName = "No name Set";
		this.balance= 0.0;
	}
	public Account(int accountNumber, String accountHolderName, double balance)
	{
		System.out.println("Parameterized Account-P");
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
		
	}

	public void setAccountNumber(int accountNumber)
	{
		this.accountNumber = accountNumber;
	}
	
	public void setAccountHolderName(String accountHolderName)
	{
		this.accountHolderName = accountHolderName;
	}
	public void setBalance(double balance)
	{
		this.balance = balance;
	}
	public int getAccountNumber(){return accountNumber;}
	public String getAccountHolderName(){return accountHolderName;}
	public double getBalance(){return balance;}
	
	public void deposit(double amount){
		if(amount>0){
			balance += amount;
		}
	}
	
	public void withdraw(double amount){
		if(balance>=amount){
			balance -= amount;
			System.out.println("Successfully WithDrawn : "+amount);
		}
		else{
			System.out.println("Not Enough Balance");
		}
	}
	
	public void showDetails()
	{
		System.out.println("Account Number: "+accountNumber);
		System.out.println("Account Holder Name: "+accountHolderName);
		System.out.println("Balance: "+balance);
		
	}
	
}