public class SavingsAccount extends Account{
		private double interestRate;

		public SavingsAccount(int accountNumber, 
							  String accountHolderName, 
							  double balance, 
							  double interestRate){
			super(accountNumber,accountHolderName,balance);
			this.interestRate = interestRate;		
			
		}
		
		public void setIntrestRate(double interestRate){
			this.interestRate = interestRate;
		}
		public double getIntrestRate(){return this.interestRate;}
		
		//Method Overriding
		public void showDetails(){
			super.showDetails();
			System.out.println("Intrest Rate: "+this.interestRate);
		}
}