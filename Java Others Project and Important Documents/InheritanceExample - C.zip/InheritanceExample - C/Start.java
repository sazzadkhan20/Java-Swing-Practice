import java.lang.*;

public class Start{
	public static void main(String args[])
	{
		Account a1 = new Account(111,"KALAM",20000);
		a1.withdraw(500);
		a1.deposit(1000);
		a1.showDetails();

		SavingsAccount sa1 = new SavingsAccount(222,"RAHIM",5000,7.5);
		sa1.showDetails(); 
		
		FixedDepositAccount fd = new FixedDepositAccount();
		fd.showDetails();
	}
}