import Classes.*;

public class Start 
{
	
	public static void main(String [] args)
	{
		new Welcome();
	}
}

