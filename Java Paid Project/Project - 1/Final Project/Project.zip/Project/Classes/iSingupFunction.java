package Classes;

public interface iSingupFunction
{
	public boolean checkingNameEntry();
	public boolean checkingDateOfBirthEntry();
	public boolean checkingEmailEntry();
	public boolean checkingNIDEntry();
	public boolean checkingPhoneNumberEntry();
	public boolean checkingAddressEntry();
	public boolean checkingPasswordEntry();
	public boolean checkingPasswordMatching();
	
}